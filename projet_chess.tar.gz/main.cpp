
#include <iostream>
#include <string>
#include <vector>


#include "game.hpp"

using namespace std;

//--------------------------------------------------------------
int main() {
    Game game;
    game.play();
    return 0;

}