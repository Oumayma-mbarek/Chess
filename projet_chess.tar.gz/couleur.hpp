#ifndef Couleur_HPP
#define Couleur_HPP
/**
 * @brief represents the color of a chess piece
 */
enum Couleur { White=0, Black=1,Blanck =2 };

#endif