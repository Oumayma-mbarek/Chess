var classGame =
[
    [ "Game", "classGame.html#ad59df6562a58a614fda24622d3715b65", null ],
    [ "is_valid_input", "classGame.html#a000bde2e6c093af3e4568d665e84bdf8", null ],
    [ "is_valid_input_long_castling", "classGame.html#a10bccbc22dde45c21e38fac39a023273", null ],
    [ "is_valid_input_short_castling", "classGame.html#ac3d2bf9458debcbeb4e7220d6527925b", null ],
    [ "play", "classGame.html#aa333825d0bca80e91e53c7e23f053405", null ]
];