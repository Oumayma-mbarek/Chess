var hierarchy =
[
    [ "Board", "classBoard.html", null ],
    [ "Game", "classGame.html", null ],
    [ "Piece", "classPiece.html", [
      [ "Bishop", "classBishop.html", null ],
      [ "King", "classKing.html", null ],
      [ "Knight", "classKnight.html", null ],
      [ "Pawn", "classPawn.html", null ],
      [ "Queen", "classQueen.html", null ],
      [ "Rook", "classRook.html", null ]
    ] ],
    [ "Player", "classPlayer.html", null ],
    [ "Spot", "classSpot.html", null ]
];