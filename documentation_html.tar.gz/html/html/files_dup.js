var files_dup =
[
    [ "board.hpp", "board_8hpp_source.html", null ],
    [ "couleur.hpp", "couleur_8hpp_source.html", null ],
    [ "game.hpp", "game_8hpp_source.html", null ],
    [ "piece.hpp", "piece_8hpp_source.html", null ],
    [ "player.hpp", "player_8hpp_source.html", null ],
    [ "spot.hpp", "spot_8hpp_source.html", null ]
];