var classKnight =
[
    [ "Knight", "classKnight.html#abd848d2b7e14d9fb3007e9c7269efc21", null ],
    [ "possible_move", "classKnight.html#add4969d705871afa4e27e9ec5a196bd4", null ]
];