var classKing =
[
    [ "King", "classKing.html#ac7a090212f2f806f8bb4d56d5a3155e2", null ],
    [ "possible_move", "classKing.html#ad90b0a627adf8884c8a7d84c397d2cbf", null ]
];