var classPawn =
[
    [ "Pawn", "classPawn.html#ae53120505047a089094f09e4043b4926", null ],
    [ "possible_move", "classPawn.html#a64b26e13f3f54841bf98c6d1ed5751aa", null ]
];