var classRook =
[
    [ "Rook", "classRook.html#a180f0e081467cb6e00c5b60368652886", null ],
    [ "possible_move", "classRook.html#acb70b24ff1bf3e886ef98410b1d749bc", null ]
];