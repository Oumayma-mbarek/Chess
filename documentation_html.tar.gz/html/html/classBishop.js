var classBishop =
[
    [ "Bishop", "classBishop.html#ac962e8e082e68eaa8a6bdc752de14983", null ],
    [ "possible_move", "classBishop.html#a48262cd80ef6a047a4c5330301868d94", null ]
];