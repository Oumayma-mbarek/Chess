var searchData=
[
  ['canonicallyprintboard_0',['canonicallyprintboard',['../classBoard.html#a530de4e57dc2a3f3ad7315030a36cc90',1,'Board']]],
  ['checkmate_1',['checkmate',['../classBoard.html#a21958320b0fa0b605ae551a34e39509a',1,'Board']]]
];
