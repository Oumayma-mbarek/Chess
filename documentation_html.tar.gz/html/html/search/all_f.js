var searchData=
[
  ['notes_0',['📄 Additional Notes',['../md_README.html#autotoc_md12',1,'']]]
];
