var searchData=
[
  ['id_0',['id',['../classPiece.html#ac40cffee50da10a50361ff4791fdd528',1,'Piece']]]
];
