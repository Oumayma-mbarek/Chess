var searchData=
[
  ['pawn_0',['Pawn',['../classPawn.html',1,'']]],
  ['piece_1',['Piece',['../classPiece.html',1,'']]],
  ['player_2',['Player',['../classPlayer.html',1,'']]]
];
