var searchData=
[
  ['🧠_20project_20overview_0',['🧠 Project Overview',['../md_README.html#autotoc_md2',1,'']]]
];
