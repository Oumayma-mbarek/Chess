var searchData=
[
  ['symbole_0',['symbole',['../classPiece.html#a31462b13a3132c930d15c94ee91fd264',1,'Piece']]]
];
