var searchData=
[
  ['game_0',['Game',['../classGame.html',1,'Game'],['../classGame.html#ad59df6562a58a614fda24622d3715b65',1,'Game::Game()']]],
  ['game_20project_20in_20c_20♚_1',['Chess Game Project in C++ ♚',['../md_README.html',1,'']]],
  ['game_20works_2',['♟️ How the Game Works',['../md_README.html#autotoc_md9',1,'']]],
  ['get_5fcol_3',['get_col',['../classSpot.html#a7bc03d063b74299e3eb9731d944ad8d7',1,'Spot']]],
  ['get_5fcolor_4',['get_color',['../classPiece.html#a207446d9c1a6750b413aae6935462507',1,'Piece']]],
  ['get_5fcouleur_5',['get_couleur',['../classPlayer.html#a1620ca9bd2ba7443330b3dffeae46705',1,'Player']]],
  ['get_5ffirstmove_6',['get_firstmove',['../classPiece.html#a47678a20f4a8d60910331924e2550667',1,'Piece']]],
  ['get_5fid_7',['get_id',['../classPiece.html#a236697193d2add8d3872aa8b6813ce79',1,'Piece']]],
  ['get_5fnom_8',['get_nom',['../classPlayer.html#a80f50bad5e3340c4f36eb1207eb2806b',1,'Player']]],
  ['get_5fpiece_9',['get_piece',['../classBoard.html#a85d688db8efad2ad422bba82764334cb',1,'Board']]],
  ['get_5fpos_10',['get_pos',['../classPiece.html#a55b9482385326c0da200b43a20fb210e',1,'Piece']]],
  ['get_5frow_11',['get_row',['../classSpot.html#a1d640da912b90f2742ea3d465141b502',1,'Spot']]],
  ['get_5fsymbole_12',['get_symbole',['../classPiece.html#a4be80209d697081020fc2c5e4bca1169',1,'Piece']]],
  ['getnocapture_13',['getnocapture',['../classBoard.html#a8e73088adf658caac218a62247040379',1,'Board']]]
];
