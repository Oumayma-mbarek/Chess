var searchData=
[
  ['_7eboard_0',['~Board',['../classBoard.html#af73f45730119a1fd8f6670f53f959e68',1,'Board']]],
  ['_7epiece_1',['~Piece',['../classPiece.html#a5d7a4f6bade94cb33b6f634de8aa7918',1,'Piece']]]
];
