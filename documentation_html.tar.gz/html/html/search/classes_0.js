var searchData=
[
  ['bishop_0',['Bishop',['../classBishop.html',1,'']]],
  ['board_1',['Board',['../classBoard.html',1,'']]]
];
