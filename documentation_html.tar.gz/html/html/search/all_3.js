var searchData=
[
  ['4_20─_20documentation_0',['4 ─ Documentation',['../md_README.html#autotoc_md8',1,'']]]
];
