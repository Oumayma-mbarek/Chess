var searchData=
[
  ['pos_0',['pos',['../classPiece.html#a38cf147ab5a3a980642bc9875bca860b',1,'Piece']]]
];
