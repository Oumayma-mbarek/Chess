var searchData=
[
  ['operator_3d_3d_0',['operator==',['../classSpot.html#a37df2c4d189b21d033eec7f3cd6f231c',1,'Spot']]]
];
