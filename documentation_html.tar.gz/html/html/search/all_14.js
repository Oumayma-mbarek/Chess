var searchData=
[
  ['set_5fcol_0',['set_col',['../classSpot.html#a82e54ad2b97f43c4b1cdff0a8ac47993',1,'Spot']]],
  ['set_5fpos_1',['set_pos',['../classPiece.html#a766a288f5fad58014b77e0c9291ed3b0',1,'Piece']]],
  ['set_5frow_2',['set_row',['../classSpot.html#a08041457250882a1b11e0e9fe274f4a9',1,'Spot']]],
  ['setfirstmove_3',['setFirstMove',['../classPiece.html#adc13c4d935aefe214692a08cef8a65c0',1,'Piece']]],
  ['setnocapture_4',['setnocapture',['../classBoard.html#aed009faf5bd69608ed69a3e3dd7af364',1,'Board']]],
  ['spot_5',['Spot',['../classSpot.html',1,'Spot'],['../classSpot.html#a3991a2599d166546af60c407b21c4596',1,'Spot::Spot()']]],
  ['stalemate_6',['stalemate',['../classBoard.html#a384d08b7eaa46b13eef1de2422ed0c91',1,'Board']]],
  ['symbole_7',['symbole',['../classPiece.html#a31462b13a3132c930d15c94ee91fd264',1,'Piece']]]
];
