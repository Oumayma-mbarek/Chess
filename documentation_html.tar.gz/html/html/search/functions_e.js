var searchData=
[
  ['validspot_0',['validspot',['../classSpot.html#a2e0c39382b635e6d47b110e392fc5d4d',1,'Spot']]]
];
