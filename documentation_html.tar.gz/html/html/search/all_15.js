var searchData=
[
  ['tests_0',['✅ Unit Tests',['../md_README.html#autotoc_md11',1,'']]],
  ['the_20game_20works_1',['♟️ How the Game Works',['../md_README.html#autotoc_md9',1,'']]],
  ['the_20program_2',['3 ─ Run the program',['../md_README.html#autotoc_md7',1,'']]],
  ['to_20compile_20and_20run_3',['⚙️ How to Compile and Run',['../md_README.html#autotoc_md4',1,'']]],
  ['to_5fstring_4',['to_string',['../classBoard.html#a734dfb4d661e28a643998101776dd33f',1,'Board::to_string()'],['../classSpot.html#a4114c5b7056bdd76f71bc23320d7fb3b',1,'Spot::to_string()']]]
];
