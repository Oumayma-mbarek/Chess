var searchData=
[
  ['♟️_20how_20the_20game_20works_0',['♟️ How the Game Works',['../md_README.html#autotoc_md9',1,'']]]
];
