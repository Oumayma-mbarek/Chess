var searchData=
[
  ['askwhichpiecewanted_0',['askwhichpiecewanted',['../classBoard.html#a5864caa098aadd7d7dbb53737ebbcf2a',1,'Board']]]
];
