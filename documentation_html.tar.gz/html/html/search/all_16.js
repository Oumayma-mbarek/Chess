var searchData=
[
  ['unit_20tests_0',['✅ Unit Tests',['../md_README.html#autotoc_md11',1,'']]],
  ['use_20makefile_1',['2 ─ Use Makefile',['../md_README.html#autotoc_md6',1,'']]]
];
