var searchData=
[
  ['little_5fcastle_0',['little_castle',['../classBoard.html#a6f22d0d0bae848031693fc76df59bf3e',1,'Board']]]
];
