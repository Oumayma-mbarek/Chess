var searchData=
[
  ['firstmove_0',['firstmove',['../classPiece.html#aa3bc2f47d8d6f6e56d51f79428106d12',1,'Piece']]]
];
