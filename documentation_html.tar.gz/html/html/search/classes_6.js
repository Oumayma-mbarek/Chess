var searchData=
[
  ['spot_0',['Spot',['../classSpot.html',1,'']]]
];
