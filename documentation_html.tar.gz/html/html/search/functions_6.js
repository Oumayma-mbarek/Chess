var searchData=
[
  ['king_0',['King',['../classKing.html#ac7a090212f2f806f8bb4d56d5a3155e2',1,'King']]],
  ['knight_1',['Knight',['../classKnight.html#abd848d2b7e14d9fb3007e9c7269efc21',1,'Knight']]]
];
