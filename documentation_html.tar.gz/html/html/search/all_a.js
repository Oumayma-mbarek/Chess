var searchData=
[
  ['how_20the_20game_20works_0',['♟️ How the Game Works',['../md_README.html#autotoc_md9',1,'']]],
  ['how_20to_20compile_20and_20run_1',['⚙️ How to Compile and Run',['../md_README.html#autotoc_md4',1,'']]]
];
