var searchData=
[
  ['2_20─_20use_20makefile_0',['2 ─ Use Makefile',['../md_README.html#autotoc_md6',1,'']]]
];
