var searchData=
[
  ['queen_0',['Queen',['../classQueen.html#a5285f15d01efc3919ba3b0226f957bc1',1,'Queen']]]
];
