var searchData=
[
  ['to_5fstring_0',['to_string',['../classBoard.html#a734dfb4d661e28a643998101776dd33f',1,'Board::to_string()'],['../classSpot.html#a4114c5b7056bdd76f71bc23320d7fb3b',1,'Spot::to_string()']]]
];
