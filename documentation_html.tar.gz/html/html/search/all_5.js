var searchData=
[
  ['big_5fcastle_0',['big_castle',['../classBoard.html#ac1e0d9617bed7946da981e5a2a77d309',1,'Board']]],
  ['bishop_1',['Bishop',['../classBishop.html',1,'Bishop'],['../classBishop.html#ac962e8e082e68eaa8a6bdc752de14983',1,'Bishop::Bishop()']]],
  ['board_2',['Board',['../classBoard.html',1,'Board'],['../classBoard.html#a9ee491d4fea680cf69b033374a9fdfcb',1,'Board::Board()']]]
];
