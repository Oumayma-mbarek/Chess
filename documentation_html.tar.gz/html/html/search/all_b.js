var searchData=
[
  ['id_0',['id',['../classPiece.html#ac40cffee50da10a50361ff4791fdd528',1,'Piece']]],
  ['implemented_1',['Key Rules Implemented',['../md_README.html#autotoc_md10',1,'']]],
  ['in_20c_20♚_2',['Chess Game Project in C++ ♚',['../md_README.html',1,'']]],
  ['incheck_3',['incheck',['../classBoard.html#a979c52310e0cc0a09094d862fae52706',1,'Board']]],
  ['install_4',['1 ─ Download dependencies and Install',['../md_README.html#autotoc_md5',1,'']]],
  ['is_5fempty_5',['is_empty',['../classBoard.html#ac75a736e416b1d3090a7dc1586597b84',1,'Board']]],
  ['is_5fvalid_5finput_6',['is_valid_input',['../classGame.html#a000bde2e6c093af3e4568d665e84bdf8',1,'Game']]],
  ['is_5fvalid_5finput_5flong_5fcastling_7',['is_valid_input_long_castling',['../classGame.html#a10bccbc22dde45c21e38fac39a023273',1,'Game']]],
  ['is_5fvalid_5finput_5fshort_5fcastling_8',['is_valid_input_short_castling',['../classGame.html#ac3d2bf9458debcbeb4e7220d6527925b',1,'Game']]]
];
