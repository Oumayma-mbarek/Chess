var searchData=
[
  ['1_20─_20download_20dependencies_20and_20install_0',['1 ─ Download dependencies and Install',['../md_README.html#autotoc_md5',1,'']]]
];
