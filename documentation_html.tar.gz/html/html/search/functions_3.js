var searchData=
[
  ['deplace_0',['deplace',['../classBoard.html#a82610086c695d5ef9d96cd5b4b35ca22',1,'Board']]],
  ['display_1',['display',['../classBoard.html#a21ee226fb2f36a5b8b7ee480bdd34ff1',1,'Board::display()'],['../classPiece.html#a015eeebd12773b9b6ffda27d393f7a26',1,'Piece::display()']]]
];
