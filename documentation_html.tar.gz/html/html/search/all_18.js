var searchData=
[
  ['willputincheck_0',['willputincheck',['../classBoard.html#af128448df3d6a7e63cc3380ee8483b26',1,'Board']]],
  ['works_1',['♟️ How the Game Works',['../md_README.html#autotoc_md9',1,'']]]
];
