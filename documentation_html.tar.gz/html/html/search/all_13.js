var searchData=
[
  ['rook_0',['Rook',['../classRook.html',1,'Rook'],['../classRook.html#a180f0e081467cb6e00c5b60368652886',1,'Rook::Rook()']]],
  ['rules_20implemented_1',['Key Rules Implemented',['../md_README.html#autotoc_md10',1,'']]],
  ['run_2',['⚙️ How to Compile and Run',['../md_README.html#autotoc_md4',1,'']]],
  ['run_20the_20program_3',['3 ─ Run the program',['../md_README.html#autotoc_md7',1,'']]]
];
