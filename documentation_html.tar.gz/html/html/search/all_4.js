var searchData=
[
  ['additional_20notes_0',['📄 Additional Notes',['../md_README.html#autotoc_md12',1,'']]],
  ['and_20install_1',['1 ─ Download dependencies and Install',['../md_README.html#autotoc_md5',1,'']]],
  ['and_20run_2',['⚙️ How to Compile and Run',['../md_README.html#autotoc_md4',1,'']]],
  ['askwhichpiecewanted_3',['askwhichpiecewanted',['../classBoard.html#a5864caa098aadd7d7dbb53737ebbcf2a',1,'Board']]]
];
