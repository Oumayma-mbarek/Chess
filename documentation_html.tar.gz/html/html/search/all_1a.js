var searchData=
[
  ['─_20documentation_0',['4 ─ Documentation',['../md_README.html#autotoc_md8',1,'']]],
  ['─_20download_20dependencies_20and_20install_1',['1 ─ Download dependencies and Install',['../md_README.html#autotoc_md5',1,'']]],
  ['─_20run_20the_20program_2',['3 ─ Run the program',['../md_README.html#autotoc_md7',1,'']]],
  ['─_20use_20makefile_3',['2 ─ Use Makefile',['../md_README.html#autotoc_md6',1,'']]]
];
