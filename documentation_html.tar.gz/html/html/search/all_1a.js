var searchData=
[
  ['♚_0',['Chess Game Project in C++ ♚',['../md_README.html',1,'']]]
];
