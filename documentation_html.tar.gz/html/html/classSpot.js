var classSpot =
[
    [ "Spot", "classSpot.html#a3991a2599d166546af60c407b21c4596", null ],
    [ "get_col", "classSpot.html#a7bc03d063b74299e3eb9731d944ad8d7", null ],
    [ "get_row", "classSpot.html#a1d640da912b90f2742ea3d465141b502", null ],
    [ "operator==", "classSpot.html#a37df2c4d189b21d033eec7f3cd6f231c", null ],
    [ "set_col", "classSpot.html#a82e54ad2b97f43c4b1cdff0a8ac47993", null ],
    [ "set_row", "classSpot.html#a08041457250882a1b11e0e9fe274f4a9", null ],
    [ "to_string", "classSpot.html#a4114c5b7056bdd76f71bc23320d7fb3b", null ],
    [ "validspot", "classSpot.html#a2e0c39382b635e6d47b110e392fc5d4d", null ]
];