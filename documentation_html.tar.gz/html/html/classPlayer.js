var classPlayer =
[
    [ "Player", "classPlayer.html#aff1be5d6d92ebdcd51842eabad760569", null ],
    [ "get_couleur", "classPlayer.html#a1620ca9bd2ba7443330b3dffeae46705", null ],
    [ "get_nom", "classPlayer.html#a80f50bad5e3340c4f36eb1207eb2806b", null ]
];