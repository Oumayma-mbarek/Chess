var classPiece =
[
    [ "Piece", "classPiece.html#a7982583185b2cf6aaa0dfd971cffcfe0", null ],
    [ "~Piece", "classPiece.html#a5d7a4f6bade94cb33b6f634de8aa7918", null ],
    [ "display", "classPiece.html#a015eeebd12773b9b6ffda27d393f7a26", null ],
    [ "get_color", "classPiece.html#a207446d9c1a6750b413aae6935462507", null ],
    [ "get_firstmove", "classPiece.html#a47678a20f4a8d60910331924e2550667", null ],
    [ "get_id", "classPiece.html#a236697193d2add8d3872aa8b6813ce79", null ],
    [ "get_pos", "classPiece.html#a55b9482385326c0da200b43a20fb210e", null ],
    [ "get_symbole", "classPiece.html#a4be80209d697081020fc2c5e4bca1169", null ],
    [ "possible_move", "classPiece.html#af8c4854ff84aae9f81f8653eaaece3ce", null ],
    [ "set_pos", "classPiece.html#a766a288f5fad58014b77e0c9291ed3b0", null ],
    [ "setFirstMove", "classPiece.html#adc13c4d935aefe214692a08cef8a65c0", null ],
    [ "couleur", "classPiece.html#abeb58424f566e8b3bcf514c731570cf8", null ],
    [ "firstmove", "classPiece.html#aa3bc2f47d8d6f6e56d51f79428106d12", null ],
    [ "id", "classPiece.html#ac40cffee50da10a50361ff4791fdd528", null ],
    [ "pos", "classPiece.html#a38cf147ab5a3a980642bc9875bca860b", null ],
    [ "symbole", "classPiece.html#a31462b13a3132c930d15c94ee91fd264", null ]
];