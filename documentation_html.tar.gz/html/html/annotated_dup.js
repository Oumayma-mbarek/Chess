var annotated_dup =
[
    [ "Bishop", "classBishop.html", "classBishop" ],
    [ "Board", "classBoard.html", "classBoard" ],
    [ "Game", "classGame.html", "classGame" ],
    [ "King", "classKing.html", "classKing" ],
    [ "Knight", "classKnight.html", "classKnight" ],
    [ "Pawn", "classPawn.html", "classPawn" ],
    [ "Piece", "classPiece.html", "classPiece" ],
    [ "Player", "classPlayer.html", "classPlayer" ],
    [ "Queen", "classQueen.html", "classQueen" ],
    [ "Rook", "classRook.html", "classRook" ],
    [ "Spot", "classSpot.html", "classSpot" ]
];