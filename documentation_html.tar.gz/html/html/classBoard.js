var classBoard =
[
    [ "Board", "classBoard.html#a9ee491d4fea680cf69b033374a9fdfcb", null ],
    [ "askwhichpiecewanted", "classBoard.html#a5864caa098aadd7d7dbb53737ebbcf2a", null ],
    [ "big_castle", "classBoard.html#ac1e0d9617bed7946da981e5a2a77d309", null ],
    [ "canonicallyprintboard", "classBoard.html#a530de4e57dc2a3f3ad7315030a36cc90", null ],
    [ "checkmate", "classBoard.html#a21958320b0fa0b605ae551a34e39509a", null ],
    [ "deplace", "classBoard.html#a82610086c695d5ef9d96cd5b4b35ca22", null ],
    [ "display", "classBoard.html#a21ee226fb2f36a5b8b7ee480bdd34ff1", null ],
    [ "get_piece", "classBoard.html#a85d688db8efad2ad422bba82764334cb", null ],
    [ "getnocapture", "classBoard.html#a8e73088adf658caac218a62247040379", null ],
    [ "incheck", "classBoard.html#a979c52310e0cc0a09094d862fae52706", null ],
    [ "is_empty", "classBoard.html#ac75a736e416b1d3090a7dc1586597b84", null ],
    [ "little_castle", "classBoard.html#a6f22d0d0bae848031693fc76df59bf3e", null ],
    [ "pathisclear", "classBoard.html#a5161e0ea6a823ff8ddf8dcd78e995ffe", null ],
    [ "pose_piece", "classBoard.html#afb591b09c767c6a48dd6c117a85dba80", null ],
    [ "setnocapture", "classBoard.html#aed009faf5bd69608ed69a3e3dd7af364", null ],
    [ "stalemate", "classBoard.html#a384d08b7eaa46b13eef1de2422ed0c91", null ],
    [ "to_string", "classBoard.html#a734dfb4d661e28a643998101776dd33f", null ],
    [ "willputincheck", "classBoard.html#af128448df3d6a7e63cc3380ee8483b26", null ]
];