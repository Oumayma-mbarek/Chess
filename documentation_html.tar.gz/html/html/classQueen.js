var classQueen =
[
    [ "Queen", "classQueen.html#a5285f15d01efc3919ba3b0226f957bc1", null ],
    [ "possible_move", "classQueen.html#ab0054cb38da0f6d38a178329c10700a0", null ]
];